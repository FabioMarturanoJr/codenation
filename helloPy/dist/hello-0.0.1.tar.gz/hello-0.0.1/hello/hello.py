#!/usr/bin/env python

def main():
    print("Hello, word")


if __name__ == '__main__':
    main()
